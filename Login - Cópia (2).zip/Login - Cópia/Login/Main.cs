﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using BusinessLogicLayer;
using System.Windows.Forms;

namespace Login
{
    public partial class Main : Form
    {
        bool flag,flag1,flag2,flag3,flag4,flag5= false;
        public Main()
        {
            InitializeComponent();
        }
        private void Main_Load(object sender, EventArgs e)
        {
             //this.Cursor = new Cursor("Z:\\Login - Cópia" + "\\Ibm.cur");
             

            label4.Text = DateTime.Now.ToLongTimeString();

            timer1.Start();
            label3.Text = DateTime.Now.ToShortDateString();

            dateTimePicker1.MaxDate = DateTime.Today.AddYears(-14);
            dateTimePicker1.MinDate = DateTime.Today.AddYears(-90);
            dateTimePicker2.MaxDate = DateTime.Today.AddYears(-18);
            dateTimePicker2.MinDate = DateTime.Today.AddYears(-90);

            textBox1.MouseHover += Common_MouseHover;
            textBox2.MouseHover += Common_MouseHover;
            textBox3.MouseHover += Common_MouseHover;
            textBox4.MouseHover += Common_MouseHover;
            textBox5.MouseHover += Common_MouseHover;
            textBox6.MouseHover += Common_MouseHover;
            textBox7.MouseHover += Common_MouseHover;
            textBox11.MouseHover += Common_MouseHover;
            textBox12.MouseHover += Common_MouseHover;
            textBox8.MouseHover += Common_MouseHover;
            textBox9.MouseHover += Common_MouseHover;
            textBox13.MouseHover += Common_MouseHover;
            textBox15.MouseHover += Common_MouseHover;
            maskedTextBox1.MouseHover += Common_MouseHover;
            maskedTextBox2.MouseHover += Common_MouseHover;
            maskedTextBox3.MouseHover += Common_MouseHover;
            maskedTextBox4.MouseHover += Common_MouseHover;
            maskedTextBox9.MouseHover += Common_MouseHover;
            maskedTextBox5.MouseHover += Common_MouseHover;
            maskedTextBox6.MouseHover += Common_MouseHover;
            maskedTextBox7.MouseHover += Common_MouseHover;
            maskedTextBox10.MouseHover += Common_MouseHover;
            maskedTextBox8.MouseHover += Common_MouseHover;
            maskedTextBox13.MouseHover += Common_MouseHover;
            maskedTextBox14.MouseHover += Common_MouseHover;
            maskedTextBox11.MouseHover += Common_MouseHover;
            maskedTextBox12.MouseHover += Common_MouseHover;
            maskedTextBox17.MouseHover += Common_MouseHover;
            maskedTextBox16.MouseHover += Common_MouseHover;
            maskedTextBox15.MouseHover += Common_MouseHover;
        }


        private void Common_MouseHover(object sender, EventArgs e)
        {
            TextBox btn = sender as TextBox;

            MaskedTextBox btn2 = sender as MaskedTextBox;
            if (btn != null)
               btn.Cursor= new Cursor("Z:\\Login - Cópia" + "\\Ibm.cur");

            if (btn2 != null)
                btn2.Cursor = new Cursor("Z:\\Login - Cópia" + "\\Ibm.cur");



        }






        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (panel3.Visible == false)
            {
                 panel3.Visible = true;
                panel4.Visible = true;
            }
            else
            {
                panel3.Visible = false;
                panel4.Visible = false;
            }
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Tomato;

        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Black;
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            label1.ForeColor = Color.Tomato;
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            label1.ForeColor = Color.Black ;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
            Login lg = new Login();
            lg.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = DateTime.Now.ToLongTimeString();

        }

 

        private void button1_Click(object sender, EventArgs e)
        {
           if (flag1 == false)
            {

                dataGridView1.DataSource = BLL.Escola.LoadA();

                button6.Visible = true;
           
              
                button9.Visible = true;
                
                button1.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                groupBox2.Visible = true;
                
            }
           if (flag1 == true)
            {
                checkBox6.Visible = false;
                checkBox7.Visible = false;
                button15.Visible = false;
                button9.Visible = false;
                button21.Visible = false;
                button22.Visible = false;
                button23.Visible = false;
                button6.Visible = false;
                button14.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;
                button31.Visible = false;
                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {
                dataGridView1.DataSource = BLL.Escola.LoadI();
                button14.Visible = true;

                button9.Visible = true;
               
            
                button2.BackColor = Color.FromArgb(255, 253, 199, 91);
                button1.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                dataGridView1.Visible = false;
               
                groupBox2.Visible = true;

            }
            if (flag1 == true)
            {
                checkBox6.Visible = false;
                checkBox7.Visible = false;
                button15.Visible = false;
                button9.Visible = false;
                button21.Visible = false;
                button22.Visible = false;
                button23.Visible = false;
                button14.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;
                button31.Visible = false;
                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {
                

                checkBox6.Visible = true;
                checkBox7.Visible = true;

                button4.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button1.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                button21.Visible = true;
                button9.Visible = true;
                

                groupBox2.Visible = true;
                groupBox1.Visible = false;
                groupBox3.Visible = false;
            }
            if (flag1 == true)
            {
                checkBox6.Visible = false;
                checkBox7.Visible = false;
                button15.Visible = false;
                button9.Visible = false;
                button21.Visible = false;
                button22.Visible = false;
                button23.Visible = false;
                button14.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;
                button31.Visible = false;
                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;

            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }
         
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (flag1 == false)
            {

                button15.Visible = true;
                
               
                button9.Visible = true;
                
                button3.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button1.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                groupBox2.Visible = true;


            }
            if (flag1 == true)
            {
                checkBox6.Visible = false;
                checkBox7.Visible = false;
                button31.Visible = false;
                button9.Visible = false;
                button21.Visible = false;
                button22.Visible = false;
                button15.Visible = false;
                button23.Visible = false;
                button14.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;
                button31.Visible = false;
                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }
         
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (flag1 == false)
            {
                try
                {

                    dataGridView1.DataSource = BLL.Escola.LoadV();
                   
                }
                catch (Exception er)
                {
                    Console.Write("n deu");
                }

                button5.BackColor = Color.FromArgb(255, 253, 199, 91);
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button1.BackColor = Color.Tomato;
                groupBox2.Visible = true;
              
                button9.Visible = true;
                button31.Visible = true;
                
              

            }
            if (flag1 == true)
            {
                checkBox6.Visible = false;
                checkBox7.Visible = false;
                button15.Visible = false;
                button9.Visible = false;
                button21.Visible = false;
                button14.Visible = false;
                button22.Visible = false;
                button23.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;
                button31.Visible = false;
                button1.BackColor = Color.Tomato;
                button2.BackColor = Color.Tomato;
                button3.BackColor = Color.Tomato;
                button4.BackColor = Color.Tomato;
                button5.BackColor = Color.Tomato;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                groupBox3.Visible = false;
                groupBox4.Visible = false;
                groupBox5.Visible = false;
                groupBox6.Visible = false;
            }
            if (flag1 == false)
            {
                flag1 = true;
            }
            else
            {
                flag1 = false;
            }
          
        }

        private void button6_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            groupBox2.Visible = false;
           
        }

        private void button11_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = true;
        }

     

        private void pictureBox4_Click(object sender, EventArgs e)
        {
           
            if (flag == false){

                pictureBox4.Image = Escola_de_condução.Properties.Resources.expand;

                var poin = new Point(100, 90);
              
                
                this.WindowState = FormWindowState.Normal;
                this.Width = (1240);
                this.Height = (700);
                this.Location=poin;

                var point = new Point(11, 583);
                this.label4.Location = point;

                var point2 = new Point(11, 631);
                this.label3.Location = point2;

                var point3 = new Point(36, 622);
                this.panel5.Location = point3;

                var point4 = new Point(25, 669);
                this.panel6.Location = point4;

                var point5 = new Point(1125, 95);
                this.panel4.Location = point5;

                var point6 = new Point(916, 23);
                this.pictureBox4.Location = point6;

                var point7 = new Point(997, 23);
                this.pictureBox2.Location = point7;

                var point8 = new Point(300, 10);
                this.pictureBox3.Location = point8;

                var point9 = new Point(900, 380);
                this.button10.Location=point9;

               
                groupBox1.Size= new Size(1050,440);
            }
            if(flag==true)
            {
                pictureBox4.Image = Escola_de_condução.Properties.Resources.minimize;
               
             
                this.WindowState = FormWindowState.Maximized;
                this.Width = (1440);
                this.Height = (900);

                
                var point = new Point(11, 783);
                this.label4.Location = point;

                var point2 = new Point(11, 831);
                this.label3.Location = point2;

                var point3 = new Point(36, 822);
                this.panel5.Location = point3;

                var point4 = new Point(25, 869);
                this.panel6.Location = point4;

                var point5 = new Point(1325, 95);
                this.panel4.Location = point5;

                var point6 = new Point(1116, 23);
                this.pictureBox4.Location = point6;

                var point7 = new Point(1197, 23);
                this.pictureBox2.Location = point7;

                var point8 = new Point(360, 10);
                this.pictureBox3.Location = point8;

                var point9 = new Point(1120, 380);
                this.button10.Location = point9;

                groupBox1.Size = new Size(1250, 440);
            }
            if (flag == false)
            {
                flag = true;
            }
            else
            {
                flag = false;
            }
        }

      

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"[0-9]");
            MatchCollection matches = regex.Matches(textBox1.Text);
            if (matches.Count > 0)
            {
                textBox1.Text = "";
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            groupBox3.Visible = true;
            groupBox2.Visible = false;
        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox9_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = false;
            groupBox4.Visible = true;
            button19.Visible = true;
            button18.Visible = true;
        }

        private void button19_Click(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
            groupBox4.Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
            groupBox3.Visible = false;
            groupBox1.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            groupBox5.Visible = true;
            groupBox2.Visible = false;
        }

        private void button22_Click(object sender, EventArgs e)
        {

        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button31_Click(object sender, EventArgs e)
        {

            groupBox6.Visible = true;
            groupBox2.Visible = false;
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            checkBox6.Checked = false;
            try
            {

               // dataGridView1.DataSource = BLL.Escola.LoadAT();
                 dataGridView1.DataSource = BLL.Escola.LoadAP();
                // n sei cm fzr
            }
            catch (Exception er)
            {
                Console.Write("n deu");
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            checkBox7.Checked= false;
            try
            {

                dataGridView1.DataSource = BLL.Escola.LoadAT();
                // dataGridView1.DataSource = BLL.Escola.LoadAP();
                // n sei cm fzr
            }
            catch (Exception er)
            {
                Console.Write("n deu");
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            //if (textBox10.Text.Length < 4)
            //{
            //    textBox10.Text += " ";
            //}
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            //if (textBox1.Text == "" || maskedTextBox2.Text==""||maskedTextBox9.Text==""|| textBox7.Text == "" || textBox11.Text == "" || comboBox1.Text == ""||maskedTextBox1.Text=="" || maskedTextBox3.Text == "" || maskedTextBox4.Text == "" || maskedTextBox9.Text == "") { 
           
            //    button10.Enabled = false;
            //}else{
            //    button10.Enabled = true;
            //}
        }
    }
}
