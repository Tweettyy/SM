﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using BusinessLogicLayer;
using System.Windows.Forms;


namespace Login
{
    
    public partial class Login : Form
    {
        bool mostrarpass=false;
        public static bool admin = false;
        public static string conta;
       public Login()
        {
            InitializeComponent();

        }
        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (BLL.Escola.Logar(Convert.ToInt32(textBox1.Text), textBox2.Text).Rows.Count > 0)
                {
                    if (Convert.ToBoolean(BLL.Escola.ShowF(Convert.ToInt32(textBox1.Text)).Rows[0][3]) == true)
                    {
                        admin = true;
                    }
                    conta = textBox1.Text;
                    this.Hide();
                    Main ma = new Main();
                    ma.Show();
                    
                }
                else
                {

                    MessageBox.Show("Utilizador ou Password errados");
                    clear();
                }

            }catch(Exception er)
            {
                //this.Hide();
                //Main ma = new Main();
                //ma.Show();
            }


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (mostrarpass == false)
            {

                pictureBox1.BackgroundImage  = Escola_de_condução .Properties.Resources.hide;
                textBox2.PasswordChar='\0';
                mostrarpass = true;
            }
            else
            {
                pictureBox1.BackgroundImage  = Escola_de_condução .Properties.Resources.view;
                textBox2.PasswordChar = '*';
                mostrarpass = false;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
            Regex regex = new Regex(@"[^A-Za-z0-9^]+");
            MatchCollection matches = regex.Matches(textBox2.Text);
            if(matches.Count > 0)
            {
                MessageBox.Show("Caracter Inválido.");
                textBox2.Text = "";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
            Regex regex = new Regex(@"[^0-9^]");
            MatchCollection matches = regex.Matches(textBox1.Text);
            if (matches.Count > 0)
            {
                MessageBox.Show("Introduza apenas numeros.");
                textBox1.Text = "";
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

      

 

     

        private void textBox1_Leave(object sender, EventArgs e)
        {
            panel1.BackColor = Color.White ;
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            panel2.BackColor = Color.White;
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                textBox2.Focus();
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)13)
                {
                    if (BLL.Escola.Logar(Convert.ToInt32(textBox1.Text), textBox2.Text).Rows.Count > 0)
                    {
                        if (Convert.ToBoolean(BLL.Escola.ShowF(Convert.ToInt32(textBox1.Text)).Rows[0][3]) == true)
                        {
                            admin = true;
                        }
                        conta = textBox1.Text;
                        this.Hide();
                        Main ma = new Main();
                        ma.Show();

                    }
                    else
                    {

                        MessageBox.Show("Utilizador ou Password errados");
                        clear();
                    }

                }

            }catch(Exception er)
            {
                //this.Hide();
                //Main ma = new Main();
                //ma.Show();
            }
         
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.White;
            textBox1.Text = "";
            panel1.BackColor = Color.Tomato;
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImage = Escola_de_condução.Properties.Resources.view;
            textBox2.ForeColor = Color.White;
            textBox2.PasswordChar = '*';
            textBox2.Text = "";
            panel2.BackColor = Color.Tomato;
        }

        private void Login_Load(object sender, EventArgs e)
        {
            button1.Focus();

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }
    }
}
