import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.border.EmptyBorder;
import java.awt.Frame;
import java.awt.Color;
import java.awt.Point;
import java.awt.SystemColor;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.border.TitledBorder;
import javax.swing.text.MaskFormatter;

import org.jdesktop.swingx.JXDatePicker;

import net.proteanit.sql.DbUtils;

import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import java.awt.Cursor;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;

public class Main extends JFrame {

	private JPanel Main;
	private final JPanel panel = new JPanel();

	/**
	 * Launch the application.
	 */
	
	ImageIcon logo = new ImageIcon(Main.class.getResource("logo.png"));
	boolean tipo =false;
	public JTable Tabela;
	private JFormattedTextField text;
	private JTextField textField;
	public static JPanel adcV = new JPanel();
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					Main frame = new Main();
					frame.setResizable(false);
					frame.setVisible(true);
					frame.setBackground(Color.LIGHT_GRAY);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setBounds(150, 100, 1100, 700);
					frame.setVisible(true);
					//frame.setUndecorated(true);					
					
					adcV.setVisible(false);
					adcV.setBackground(Color.WHITE);
					adcV.setBounds(165, 120, 929, 552);
					adcV.setLayout(null);
					adcV.setVisible(false);
					frame.getContentPane().add(adcV);
					
					
			        JXDatePicker picker = new JXDatePicker();
			        picker.setDate(Calendar.getInstance().getTime());
			        picker.setTimeZone(Calendar.getInstance().getTimeZone());
			        picker.setFormats(new SimpleDateFormat("dd.MM.yyyy HH:mm"));
			        picker.setBounds(300,300,150,20);
			        
			        
			        adcV.add(picker);
			        
                  
					
					
			        
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	void loadv(){
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
			Statement stmt=con.createStatement();
			String sql="Select * from Veiculos";
			ResultSet rs=stmt.executeQuery(sql);
			
			//table_1.setModel(DbUtils.resultSetToTableModel(rs));
			Tabela.setModel(DbUtils.resultSetToTableModel(rs));
			Tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			System.out.println("Carregar dados para a tabela");
			con.close();
			}catch(Exception ee){System.out.println(ee);}	
			
			

	}
	void loada(){
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rentacar","root","");
			Statement stmt=con.createStatement();
			String sql="Select * from Alugados";
			ResultSet rs=stmt.executeQuery(sql);
			
			//table_1.setModel(DbUtils.resultSetToTableModel(rs));
			Tabela.setModel(DbUtils.resultSetToTableModel(rs));
			Tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			System.out.println("Carregar dados para a tabela");
			con.close();
			}catch(Exception ee){System.out.println(ee);}	
			
			

	}
		public Main() throws ParseException {
		
			Main = new JPanel();
			Main.setBackground(Color.LIGHT_GRAY);
			Main.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(Main);
			Main.setLayout(null);
		
		
		
		
    

		
		text = new JFormattedTextField();
		text.setText("AA-AA-AA");
		text.setFont(new Font("Dialog", Font.PLAIN, 23));
		text.setBounds(200, 100, 110, 30);
		
	    MaskFormatter maskData = new MaskFormatter("AA-AA-AA");
		maskData.install(text);
		
		adcV.add(text);
		text.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Matricula:");
		lblNewLabel.setFont(new Font("Dialog", Font.PLAIN, 25));
		lblNewLabel.setBounds(80, 100, 116, 30);
		adcV.add(lblNewLabel);
		
		JLabel lblVeiculo = new JLabel("Veiculo");
		lblVeiculo.setHorizontalAlignment(SwingConstants.CENTER);
		lblVeiculo.setFont(new Font("Dialog", Font.BOLD, 30));
		lblVeiculo.setBounds(348, 11, 135, 27);
		adcV.add(lblVeiculo);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(345, 45, 145, 2);
		adcV.add(panel_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBackground(Color.BLACK);
		panel_1_1.setBounds(330, 50, 175, 2);
		adcV.add(panel_1_1);
		
		
		
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBackground(new Color(204, 255, 255));
		panel.setBounds(0, 0, 1100, 120);
		Main.add(panel);
		panel.setLayout(null);
		
		JScrollPane tab = new JScrollPane();
		tab.setBounds(176, 173, 908, 487);
		tab.setVisible(false);
		Main.add(tab);
		
		Tabela=new JTable();
		tab.setViewportView(Tabela);
		
		JLabel Logo = new JLabel();
		Logo.setBounds(30, 10, 150, 100);
		Logo.setIcon(logo);
		panel.add(Logo);
		
		JPanel panel2 = new JPanel();
		panel2.setVisible(false);
		panel2.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel2.setBackground(new Color(204, 255, 255));
		panel2.setBounds(0, 70, 165, 600);
		Main.add(panel2);
		panel2.setLayout(null);
		
		JLabel Consultar = new JLabel("Consultar");
		Consultar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Consultar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
		Consultar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Consultar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(204, 0,51 )));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Consultar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
			}
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
					adcV.setVisible(false);
					tab.setVisible(true);
					if(tipo==false) {
						loada();
					}
					else {
						loadv();
						//int valor =Tabela.rowAtPoint(0,0);
						 JProgressBar pr = new JProgressBar();
					     pr.setStringPainted(true);
					     pr.setValue(0);
					     pr.setSize(new Dimension(100, 23));
					     Tabela.add(pr);
						
					}
				
				
				
			}
		});
		
		Consultar.setBackground(Color.WHITE);
		Consultar.setForeground(Color.BLACK);
		Consultar.setHorizontalAlignment(SwingConstants.CENTER);
		Consultar.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));
		Consultar.setBounds(6, 80, 155, 59);
		panel2.add(Consultar);
		
		JLabel Adicionar = new JLabel("Adicionar");
		Adicionar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Adicionar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
		Adicionar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Adicionar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(204, 0,51 )));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Adicionar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				tab.setVisible(false);
				adcV.setVisible(true);
			}
		});
		Adicionar.setHorizontalAlignment(SwingConstants.CENTER);
		Adicionar.setForeground(Color.BLACK);
		Adicionar.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));
		Adicionar.setBackground(Color.WHITE);
		Adicionar.setBounds(6, 180, 155, 59);
		panel2.add(Adicionar);
		
		JLabel Remover = new JLabel("Remover");
		Remover.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Remover.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
		Remover.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Remover.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(204, 0,51 )));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Remover.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
			}
		});
		Remover.setHorizontalAlignment(SwingConstants.CENTER);
		Remover.setForeground(Color.BLACK);
		Remover.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));
		Remover.setBackground(Color.WHITE);
		Remover.setBounds(6, 280, 155, 59);
		panel2.add(Remover);
		
		JLabel Editar = new JLabel("Editar");
		Editar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Editar.setVisible(false);
		Editar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
		Editar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				Editar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(204, 0, 51)));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				Editar.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 255)));
			}
		});
		Editar.setHorizontalAlignment(SwingConstants.CENTER);
		Editar.setForeground(Color.BLACK);
		Editar.setFont(new Font("Eras Demi ITC", Font.PLAIN, 27));

		Editar.setBackground(Color.WHITE);
		Editar.setBounds(6, 380, 155, 59);
		panel2.add(Editar);
		
		JLabel Alugados = new JLabel("Alugados");
		Alugados.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Alugados.setForeground(new Color(0, 0, 0));
	
		Alugados.setHorizontalAlignment(SwingConstants.CENTER);
		Alugados.setFont(new Font("Eras Bold ITC", Font.BOLD, 30));
		Alugados.setBounds(300, 10, 230, 100);
		panel.add(Alugados);
	
		JLabel Veiculos = new JLabel("Veiculos");
		Veiculos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Veiculos.setHorizontalAlignment(SwingConstants.CENTER);
		Veiculos.setFont(new Font("Eras Bold ITC", Font.BOLD, 30));
		Veiculos.setBounds(670, 10, 230, 100);
		panel.add(Veiculos);
		
		JLabel Data = new JLabel("data");
		Data.setFont(new Font("Eras Bold ITC", Font.PLAIN, 14));
		Data.setBounds(999, 10, 111, 20);
		panel.add(Data);
		
		
		JLabel Hora = new JLabel("hora");
		Hora.setFont(new Font("Eras Bold ITC", Font.PLAIN, 14));
		Hora.setBounds(1035, 28, 111, 20);
		panel.add(Hora);
		
	
		
		
		Veiculos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panel2.setVisible(true);
				Veiculos.setForeground(new Color(204,0,51));
				Alugados.setForeground(new Color(0,0,0));
				Editar.setVisible(true);
				tab.setVisible(false);
				tipo=true;
			}
		});
		
		Alugados.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				panel2.setVisible(true);
				Alugados.setForeground(new Color(204,0,51));
				Veiculos.setForeground(new Color(0,0,0));
				Editar.setVisible(false);
				tab.setVisible(false);
				tipo=false;
			}
		});
		
		Timer timer=new Timer();
		TimerTask task =new TimerTask() {

			@Override
			public void run() {
				
				Data.setText(new SimpleDateFormat("dd/MM/yyyy").format(new Date(System.currentTimeMillis())));
				Hora.setText(new SimpleDateFormat("HH:mm").format(new Date(System.currentTimeMillis())));
			}
			
		};
		

		timer.scheduleAtFixedRate(task, 0, 80);
	}
}
