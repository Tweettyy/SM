﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLogicLayer
{
    public class BLL
    {
        public class Imagem
        {
            static public object loadpic()
            {
                DAL dal = new DAL();
                 SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", 1),
             };
                return dal.executarScalar("select Img from Imagem where id=1", sqlParams);
            
            }
            static public DataTable Load()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Imagem", null);
            }

            static public int insertImagem(byte [] img )
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@img", img),
                
           };

                return dal.executarNonQuery("INSERT into Imagem (Img) VALUES(@img)", sqlParams);
            }
        }
        public class Clientes
        {

            static public DataTable Load()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Clientes", null);
            }
            static public int insertCliente(string nome, string morada, string telefone)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@nome", nome),
                new SqlParameter("@morada", morada),
                new SqlParameter("@telefone", telefone)
           };

                return dal.executarNonQuery("INSERT into Cliente (Nome,Morada,Telefone) VALUES(@nome,@morada,@telefone)", sqlParams);
            }
            static public DataTable queryCliente_Like(String nome)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@nome", nome + "%")
                };
                return dal.executarReader("select * from Clientes where Nome like @nome", sqlParams);
            }
            static public DataTable queryCliente(int id) {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id)
                };
                return dal.executarReader("select * from Clientes where ID=@id", sqlParams);
            }
            static public DataTable queryCliente_2(int id, string nome)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),
                 new SqlParameter("@Nome", nome)
                };
                return dal.executarReader("select * from Clientes where ID=@id and Nome=@nome", sqlParams);
            }
            static public DataTable queryCliente_3(int id)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id)
                };
                return dal.executarReader("select * from Clientes where ID=@id", sqlParams);
            }
            static public int updateCliente(string id, string nome, string morada, string telefone)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),
                new SqlParameter("@nome", nome),
                new SqlParameter("@morada", morada),
                new SqlParameter("@telefone", telefone)
            };
                return dal.executarNonQuery("update [Clientes] set [nome]=@nome, [morada]=@morada, [telefone]=@telefone where [id]=@id", sqlParams);
            }
            static public int deleteCliente(string id)            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),
               
            };
                return dal.executarNonQuery("Delete From Clientes WHERE[id]=@id", sqlParams);
            }
            static public int alterarPerfil(string utilizador, String password, string imagem)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlparams = new SqlParameter[]{
                    new SqlParameter("@utilizador", utilizador),
                    new SqlParameter("@password", password),
                    new SqlParameter("@imagem", imagem)};

                return dal.executarNonQuery("update [utilizadores] set [password]=@password, [imagem]=@imagem where [utilizador]=@utilizador", sqlparams);
            }
            static public int alterarEstado(string utilizador, int estado)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlparams = new SqlParameter[]{
                    new SqlParameter("@utilizador", utilizador),
                    new SqlParameter("@estado", estado)};

                return dal.executarNonQuery("update utilizadores set estado=@estado where utilizador=@utilizador", sqlparams);
            }

        }
        public class Escola
        {
            static public DataTable LoadA()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Aluno", null);
            }
            static public DataTable LoadI()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Instrutor", null);
            }
            static public DataTable LoadAT()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Aula_Teorica", null);
            }
            static public DataTable LoadAP()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Aula_Pratica", null);
            }
            static public DataTable LoadET()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Exame_Teorico", null);
            }
            static public DataTable LoadEP()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Exame_Pratico", null);
            }
            static public DataTable LoadV()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Veiculo", null);
            }
            static public DataTable LoadF()
            {
                DAL dal = new DAL();
                return dal.executarReader("select * from Funcionário", null);
            }
            static public DataTable Logar(int id, string password)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@id", id),
                 new SqlParameter("@password", password)
                };
                return dal.executarReader("select * from Funcionário where ID=@id and password=@password", sqlParams);
            }

            static public int insertAluno(string Nome, string CC, DateTime DT_Nascimento,string Morada,string Cod_Postal,string Telemovel,string Email,string NIF, string NIB, string Categoria)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@CC", CC),
                new SqlParameter("@DT_Nascimento", DT_Nascimento),
                new SqlParameter("@Morada", Morada),
                new SqlParameter("@Cod_Postal", Cod_Postal),
                new SqlParameter("@Telemovel", Telemovel),
                new SqlParameter("@Email", Email),
                new SqlParameter("@NIF", NIF),
                new SqlParameter("@NIB", NIB),
                new SqlParameter("@Categoria", Categoria),
           };

                return dal.executarNonQuery("INSERT into Aluno (Nome,CC,DT_Nascimento,Morada,Cod_Postal,Telemovel,Email,NIF,NIB,Categoria) VALUES(@Nome,@CC,@DT_Nascimento,@Morada,@Cod_Postal,@Telemovel,@Email,@NIF,@NIB,@Categoria)", sqlParams);
            }

            static public int insertInstrutor(string Nome, string CC, DateTime DT_Nascimento, string Morada, string Cod_Postal, string Telemovel, string Email, string NIF, string NIB, Boolean Habilitação)
            {
                DAL dal = new DAL();
                SqlParameter[] sqlParams = new SqlParameter[]{
                new SqlParameter("@Nome", Nome),
                new SqlParameter("@CC", CC),
                new SqlParameter("@DT_Nascimento", DT_Nascimento),
                new SqlParameter("@Morada", Morada),
                new SqlParameter("@Cod_Postal", Cod_Postal),
                new SqlParameter("@Telemovel", Telemovel),
                new SqlParameter("@Email", Email),
                new SqlParameter("@NIF", NIF),
                new SqlParameter("@NIB", NIB),
                new SqlParameter("@Habilitação", Habilitação),
           };

                return dal.executarNonQuery("INSERT into Instrutor (Nome,CC,DT_Nascimento,Morada,Cod_Postal,Telemovel,Email,NIF,NIB,Habilitação) VALUES(@Nome,@CC,@DT_Nascimento,@Morada,@Cod_Postal,@Telemovel,@Email,@NIF,@NIB,@Habilitação)", sqlParams);
            }
        }
    }
}